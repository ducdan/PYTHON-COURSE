CREATE FUNCTION _pg_truetypid (pg_attribute, pg_type) RETURNS oid
	LANGUAGE sql
AS $$
SELECT CASE WHEN $2.typtype = 'd' THEN $2.typbasetype ELSE $1.atttypid END
$$
