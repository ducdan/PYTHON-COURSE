CREATE FUNCTION textanycat (text, anynonarray) RETURNS text
	LANGUAGE sql
AS $$
select $1 || $2::pg_catalog.text
$$
