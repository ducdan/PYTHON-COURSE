CREATE FUNCTION obj_description (oid) RETURNS text
	LANGUAGE sql
AS $$
select description from pg_catalog.pg_description where objoid = $1 and objsubid = 0
$$
